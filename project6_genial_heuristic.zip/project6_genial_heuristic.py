import os
import numpy as np
from ompl import base as ob
from ompl import control as oc
from ompl import geometric as og
import pydot
from IPython.display import SVG, display
import matplotlib.pyplot as plt
from pydrake.common import temp_directory
from pydrake.geometry import StartMeshcat, Box as DrakeBox
from pydrake.math import RotationMatrix, RigidTransform, RollPitchYaw
from pydrake.multibody.parsing import Parser
from pydrake.multibody.plant import AddMultibodyPlantSceneGraph, MultibodyPlant
from pydrake.systems.analysis import Simulator
from pydrake.systems.framework import DiagramBuilder
from pydrake.visualization import AddDefaultVisualization
from pydrake.systems.framework import LeafSystem
from pydrake.systems.primitives import ConstantVectorSource, LogVectorOutput
from pydrake.all import Variable, MakeVectorVariable

from helper.dynamics import CalcRobotDynamics
from pydrake.all import (
    InverseKinematics, Solve,
    SpatialInertia, UnitInertia,
    RigidTransform, CoulombFriction
)
from pydrake.systems.framework import LeafSystem, BasicVector
from pydrake.trajectories import PiecewisePolynomial


# Start the visualizer and clean up previous instances
meshcat = StartMeshcat()
meshcat.Delete()
meshcat.DeleteAddedControls()


# Path to Panda robot URDF and the world SDF
world_path = os.path.join("..", "models", "descriptions", "project_06_TAMP.sdf")
robot_path = os.path.join("..", "models", "descriptions", "robots", "arms",
                          "franka_description", "urdf", "panda_arm_hand.urdf")



######################################################################################################
#                             ########Define PD+G Controller as a LeafSystem #######   
######################################################################################################
class Controller(LeafSystem):
    def __init__(self, plant, robot, waypoints):
        super().__init__()

        # Declare input ports for desired and current states
        self._current_state_port = self.DeclareVectorInputPort(name="Current_state", size=18)
        # self._desired_state_port = self.DeclareVectorInputPort(name="Desired_state", size=9)

        # PD+G gains (Kp and Kd)
        self.Kp_ = np.array([120.0, 120.0, 120.0, 120.0, 120.0, 120.0, 120.0, 120, 120])
        self.Kd_ = np.array([30.0, 30.0, 30.0, 30.0, 30.0, 30.0, 30.0, 5, 5])
        self.robot = robot
        self.waypoints = [np.asarray(w) for w in waypoints]


        # Store plant and context for dynamics calculations
        self.plant, self.plant_context_ad = plant, plant.CreateDefaultContext()

        self.sample_period = 2.8
        self.last_sample_time = -np.inf
        self.q_d_hold = None
        self.wp_index = 0


        # Declare discrete state and output port for control input (tau_u)
        state_index = self.DeclareDiscreteState(9)  # 9 state variables.
        self.DeclareStateOutputPort("tau_u", state_index)  # output: y=x.
        self.DeclarePeriodicDiscreteUpdateEvent(
            period_sec=1/1000,  # One millisecond time step.
            offset_sec=0.0,  # The first event is at time zero.
            update=self.compute_tau_u) # Call the Update method defined below.
    
    # def compute_tau_u(self, context, discrete_state):
    #     num_positions = self.plant.num_positions(self.robot)
    #     num_velocities = self.plant.num_velocities(self.robot)

    #     # Evaluate the input ports 0.5, 0.25, 0.29
    #     for 
    #         self.q_d = self.waypoints[i]
        
        
    #     self.q = self._current_state_port.Eval(context)

    #     # Compute gravity forces for the current state
    #     self.plant.SetPositionsAndVelocities(self.plant_context_ad, self.robot, self.q)
    #     gravity = -self.plant.CalcGravityGeneralizedForces(self.plant_context_ad)[:num_positions]
        
    #     tau = self.Kp_ * (self.q_d - self.q[:num_positions]) - self.Kd_ * self.q[num_positions:] + gravity
    #     #print(tau)
    #     # Update the output port = state
    #     discrete_state.get_mutable_vector().SetFromVector(tau)

    def compute_tau_u(self, context, discrete_state):
        num_positions = self.plant.num_positions(self.robot)
        num_velocities = self.plant.num_velocities(self.robot)

        t = context.get_time()
        self.q = self._current_state_port.Eval(context)

        # --- Sample & hold desired reference ---
        if (t - self.last_sample_time) >= self.sample_period:
            self.q_d_hold = self.waypoints[self.wp_index]
            self.last_sample_time = t

            # Optional: advance waypoint index safely
            self.wp_index = min(self.wp_index + 1, len(self.waypoints) - 1)

        q_d = self.q_d_hold

        # --- Dynamics terms ---
        self.plant.SetPositionsAndVelocities(
            self.plant_context_ad, self.robot, self.q
        )
        gravity = -self.plant.CalcGravityGeneralizedForces(
            self.plant_context_ad
        )[:num_positions]

        # --- PD + gravity compensation ---
        tau = (
            self.Kp_ * (q_d - self.q[:num_positions])
            - self.Kd_ * self.q[num_positions:]
            + gravity
        )

        discrete_state.get_mutable_vector().SetFromVector(tau)



######################################################################################################
#                     ########Define Trajectory Generator as a LeafSystem #######   
######################################################################################################
class JointSpaceValidityChecker(ob.StateValidityChecker):
    def __init__(self, si, check_fn, num_dof):
        super().__init__(si)
        self.check_fn = check_fn
        self.num_dof = num_dof

    def isValid(self, state):
        q = np.array([state[i] for i in range(self.num_dof)])
        return self.check_fn(q)

######################################################################################################

def plot_joint_tracking(logger_state, logger_traj, simulator_context, num_joints=9):
    """
    Plot actual vs reference joint positions and velocities from logs.
    """
    log_state = logger_state.FindLog(simulator_context)
    log_traj = logger_traj.FindLog(simulator_context)

    time = log_state.sample_times()
    q_actual = log_state.data()[:num_joints, :]
    qdot_actual = log_state.data()[num_joints:, :]

    q_ref = log_traj.data()[:num_joints, :]

    # --- Joint positions ---
    fig, axes = plt.subplots(7, 1, figsize=(12, 14), sharex=True)
    for i in range(7):
        axes[i].plot(time, q_actual[i, :], label='q_actual')
        axes[i].plot(time, q_ref[i, :], '--', label='q_ref')
        axes[i].set_ylabel(f'Joint {i+1} [rad]')
        axes[i].legend()
        axes[i].grid(True)
        axes[i].set_ylim(-3, 3)
    axes[-1].set_xlabel('Time [s]')
    fig.suptitle('Joint Positions: Actual vs Reference')
    plt.tight_layout(rect=[0, 0, 1, 0.97])
    plt.show()

def make_panda_ik(panda_path,time_step):
    plant = MultibodyPlant(time_step)
    parser = Parser(plant)
    parser.AddModelsFromUrl("file://" + os.path.abspath(panda_path))
  
    base = plant.GetBodyByName("panda_link0")
    plant.WeldFrames(plant.world_frame(), base.body_frame())
    
    plant.Finalize()
    return plant

def solve_ik(plant, context, frame_E, X_WE_desired):
    """
    Solves inverse kinematics for a given end-effector pose.

    Args:
        plant: MultibodyPlant
        context: plant.CreateDefaultContext() or similar
        frame_E: End-effector Frame (e.g. plant.GetFrameByName("ee"))
        X_WE_desired: RigidTransform of desired world pose of end-effector

    Returns:
        q_solution: numpy array of joint positions if successful, else None
    """
    ik = InverseKinematics(plant, context)

    # Set nominal joint positions to current positions
    q_nominal = plant.GetPositions(context).reshape((-1, 1))

    
    # Constrain position and orientation
    # Position constraint
    p_AQ = X_WE_desired.translation().reshape((3, 1))
    ik.AddPositionConstraint(
        frameB=frame_E,
        p_BQ=np.zeros((3, 1)),  # Here, p_BQ = [0, 0, 0] means we’re constraining the origin of the E frame.
        frameA=plant.world_frame(),
        p_AQ_lower=p_AQ,
        p_AQ_upper=p_AQ
    )

    # Orientation constraint
    theta_bound = 1e-2  # radians
    ik.AddOrientationConstraint(
        frameAbar=plant.world_frame(),      # world frame
        R_AbarA=X_WE_desired.rotation(),    # desired orientation
        frameBbar=frame_E,                  # end-effector frame
        R_BbarB=RotationMatrix(),           # current orientation
        theta_bound=theta_bound             # allowable deviation
    )

    # Access the underlying MathematicalProgram to add costs and constraints manually.
    prog = ik.prog()
    q_var = ik.q()  # decision variables (joint angles)
    # Add a quadratic cost to stay close to the nominal configuration:
    #   cost = (q - q_nominal)^T * W * (q - q_nominal)
    W = np.identity(q_nominal.shape[0])
    prog.AddQuadraticErrorCost(W, q_nominal, q_var)

    # Enforce joint position limits from the robot model.
    lower = plant.GetPositionLowerLimits()
    upper = plant.GetPositionUpperLimits()
    prog.AddBoundingBoxConstraint(lower, upper, q_var)


    # Solve the optimization problem using Drake’s default solver.
    # The initial guess is the nominal configuration (q_nominal).
    result = Solve(prog, q_nominal)

    # Check if the solver succeeded and return the solution.
    if result.is_success():
        q_sol = result.GetSolution(q_var)
        return q_sol
    else:
        print("IK did not converge!")
        return None

def get_cube_poses(plant, context):
    cubes = ["red_link", "green_link", "blue_link"]
    poses = {}

    for link_name in cubes:
        body = plant.GetBodyByName(link_name)
        X_WB = plant.EvalBodyPoseInWorld(context, body)
        poses[link_name] = X_WB

    return poses

def pick_and_place(final_configuration, plant, context):
    #final_configuration : dico {cube_name : pose} qui donne la configuration finale du cube de la tour le plus bas au plus haut

    current_poses = get_cube_poses(plant, context)
    #print(current_poses)
    operations = []  # List of (cube, action, pose) in execution order  

    intermediate_x_pattern = [1, -1, 0, 0, -1, 1, 1, 0]
    intermediate_y_pattern = [0, 0, 1, -1, 1, 1, -1, -1]
    intermediate_amount = 0
    m = 0.025*3 # assuming block size of 0.025m
    n = m # assuming block size of 0.025m

    at_final = []
    #print(len(final_configuration))
    
    break_flag = False
    for cube in current_poses: # loop to move all cubes to their intermediate positions first
        
        current_pose = current_poses[cube]
        target_pose = final_configuration[cube]
        
        if np.linalg.norm(current_pose.translation()- target_pose.translation()) < 1e-3 :
            # print(f"{cube} already at target position.")
            at_final.append(cube)
            continue  # on ne fait rien si le cube est déjà placé à sa target position

        print(f"{cube} not at target position. Planning pick and place.")
        pos = current_pose.translation()

        for other, other_pose in reversed(current_poses.items()):
            same_xy = (abs(pos[0] - other_pose.translation()[0]) < 0.05 and abs(pos[1] - other_pose.translation()[1]) < 0.05 )
            above = other_pose.translation()[2] > pos[2]
            # print(f"Checking if {other} is blocking {cube}: same_xy={same_xy}, above={above}")
            i = 0
            if (same_xy and above) or (other == cube):
                b = other
                ps = current_poses[b].translation().copy()
                ps[2]+=0.06
                if ps[2] <0.1675:
                    ps[2]= 0.168
                ps_ = RigidTransform(RollPitchYaw(0, 0, 0), ps)
                
                operations.append((b, "pick", ps_))
                
                # Determine which cycle we're in (0-based)
                cycle = intermediate_amount // 8
                
                # Determine position within cycle
                pos_in_cycle = intermediate_amount % 8
                
                # Scale increases with cycle number
                scale = cycle + 1
                
                intermediate_trans = other_pose.translation().copy()
                # Calculate the movement
                intermediate_trans[0] += intermediate_x_pattern[pos_in_cycle] * scale * n
                intermediate_trans[1] += intermediate_y_pattern[pos_in_cycle] * scale * m
                intermediate_trans[2] = 0.1675#0.05+0.025/2 # height of cube on table
                print(intermediate_trans,intermediate_amount)
                intermediate_pos = RigidTransform(RotationMatrix.Identity(), intermediate_trans)
                intermediate_amount += 1
                
                operations.append((b,"place", intermediate_pos))
                current_poses[b] = intermediate_pos #je pense on peut supp cette ligne
                if other == cube:
                    break_flag = True
                    break  # no need to pick and place itself again
            
        if break_flag:
            # print(f"Breaking out of cube loop after handling {cube}.")
            break
        
    for cube in final_configuration: # loop to move all cubes to their final positions
        if cube in at_final:
            continue  # skip cubes already at final position

        current_pose = current_poses[cube]
        target_pose = final_configuration[cube]

        # print(f"Picking and placing {cube} to target position.")

        operations.append((cube,"pick", current_pose))
        operations.append((cube,"place", target_pose))
        current_poses[cube] = target_pose

    return operations
def gripper_action(pt, offset):
    p = pt.copy()
    p[7] = offset
    p[8] = offset
    return p


# Function to Create Simulation Scene
def create_sim_scene(sim_time_step):   
    builder = DiagramBuilder()
    trajectory_mode = "trapezoidal"  # Options: "trapezoidal" or "s_curve"
    plant, scene_graph = AddMultibodyPlantSceneGraph(builder, time_step=sim_time_step)


    Parser(plant).AddModelsFromUrl("file://" + os.path.abspath(world_path))[0]           # loads tables, cubes, etc.
    panda_model = Parser(plant).AddModelsFromUrl("file://" + os.path.abspath(robot_path))[0]   # loads the Panda robot

    base_link = plant.GetBodyByName("panda_link0")  # replace with your robot’s root link name
    plant.WeldFrames(plant.world_frame(), base_link.body_frame())

    
    plant.Finalize()
    
    robot = plant.GetModelInstanceByName("panda")
    # Set the initial joint position of the robot otherwise it will correspond to zero positions
    q_start = [-1.0, -0, 0.0, -2.356, 0.0, 1.571, 0.785, 0.0, 0.0]
    plant.SetDefaultPositions(robot, q_start)
    #print(plant.GetDefaultPositions())


    # Add visualization to see the geometries in MeshCat
    AddDefaultVisualization(builder=builder, meshcat=meshcat)

    
    # Create a constant source for desired positions
    panda_ik = make_panda_ik(panda_path=robot_path,time_step=sim_time_step)
    panda_ik.SetDefaultPositions([-1.0, -0, 0.0, -2.356, 0.0, 1.571, 0.785, 0.0, 0.0])
    context_panda_ik = panda_ik.CreateDefaultContext()
    frame_E = panda_ik.GetFrameByName("panda_hand")

   
    context = plant.CreateDefaultContext()


    # final configuration of the cubes (from bottom to top)    
    # desired_order = ["red_link", "blue_link", "green_link"]
    desired_order = ["blue_link", "green_link","red_link"]

    #desired_circle = "link_initial"  # "link_initial" or "link_target"
    #X_WB_circle = plant.EvalBodyPoseInWorld(context, plant.GetBodyByName(desired_circle))
    cylinder_target_instance = plant.GetModelInstanceByName("cylinder_target")

    cylinder_target_body = plant.GetBodyByName("link_target",cylinder_target_instance)
    X_WB_circle = plant.EvalBodyPoseInWorld(context, cylinder_target_body)

    final_configuration = {}
    for i, cube_name in enumerate(desired_order):
        height = 0.05 + 0.025/2 + (i)*0.025   # wall height + cube height/2 + stack height
        final_configuration[cube_name] = RigidTransform(RotationMatrix.Identity(), [X_WB_circle.translation()[0], X_WB_circle.translation()[1], height]) 

    pick_place_sequence = pick_and_place(final_configuration, plant, context)
    #print("Pick and Place Sequence:", pick_place_sequence)

    X_WE_desired_1 = RigidTransform(  RollPitchYaw(np.pi, 0, 0),[0.5, -0.25, 0.167])
    q_t1 = solve_ik(panda_ik, context_panda_ik, frame_E, X_WE_desired_1) 
    q_t1[7]= 0.001
    q_t1[8]= 0.001


    way_pts = []
    offset = 0.1

    #apply an offset in z  + ik
    for i in range(6):
        
        X = pick_place_sequence[i][2]
        p = X.translation().copy()   # np.array (3,)
        p[2]+= offset
        if p[2] < 0.1675:
            p[2] = 0.1675
        way_pts.append(('----',solve_ik(panda_ik, context_panda_ik, frame_E,RigidTransform(RollPitchYaw(np.pi, 0, 0), p))))
        way_pts.append((pick_place_sequence[i][1],solve_ik(panda_ik, context_panda_ik, frame_E,RigidTransform(RollPitchYaw(np.pi, 0, 0), X.translation()))))
        way_pts.append(('----',solve_ik(panda_ik, context_panda_ik, frame_E,RigidTransform(RollPitchYaw(np.pi, 0, 0), p))))
    print(pick_place_sequence[5])
    print(pick_place_sequence[6])
    
    way_pts_bis = []
    for i in (way_pts):
        prev = ''
        if i[0]=='place':
            way_pts_bis.append(gripper_action(i[1],0.00))
            way_pts_bis.append(gripper_action(i[1],0.04))
        elif i[0]=='pick':
            way_pts_bis.append(gripper_action(i[1],0.04))
            way_pts_bis.append(gripper_action(i[1],0.00))
        else:
            way_pts_bis.append(i[1])

    #print(len(way_pts_bis))

    # Add a PD+G controller to regulate the robot
    controller = builder.AddNamedSystem("PD+G controller", Controller(plant, robot, waypoints=way_pts_bis))

    # path_planner = builder.AddNamedSystem("Motion Profile",MotionProfile(waypoints=way_pts_bis))

    # Connect systems: plant outputs to controller inputs, and vice versa
    
    # builder.Connect(plant.GetOutputPort("panda_state"), path_planner.GetInputPort("state"))
    # builder.Connect(path_planner.get_output_port(0), controller.GetInputPort("Desired_state"))
    builder.Connect(plant.GetOutputPort("panda_state"), controller.GetInputPort("Current_state")) 
    builder.Connect(controller.GetOutputPort("tau_u"), plant.GetInputPort("panda_actuation"))
    


    # logger_state = LogVectorOutput(plant.GetOutputPort("panda_state"), builder)
    # logger_state.set_name("State logger")

    # logger_traj = LogVectorOutput(path_planner.get_output_port(0), builder)
    # logger_traj.set_name("Trajectory logger")

    # Build and return the diagram
    diagram = builder.Build()
    return diagram #, logger_state, logger_traj

# Create a function to run the simulation scene and save the block diagram:
def run_simulation(sim_time_step):
    diagram = create_sim_scene(sim_time_step)
    simulator = Simulator(diagram)
    simulator_context = simulator.get_mutable_context()
    simulator.Initialize()
    simulator.set_target_realtime_rate(1.0)

    # Save the block diagram as an image file
    svg_data = diagram.GetGraphvizString(max_depth=2)
    graph = pydot.graph_from_dot_data(svg_data)[0]
    image_path = "figures/block_diagram_04_path_planner.png"  # Change this path as needed
    graph.write_png(image_path)
    print(f"Block diagram saved as: {image_path}")
    
    # Run simulation and record for replays in MeshCat
    meshcat.StartRecording()
    simulator.AdvanceTo(10.0)  # Adjust this time as needed
    meshcat.PublishRecording()

    # At the end of the simulation
    # plot_joint_tracking(logger_state, logger_traj, simulator.get_context())

# Run the simulation with a specific time step. Try gradually increasing it!
run_simulation(sim_time_step=0.0005)
